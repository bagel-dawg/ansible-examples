
Example run:
$> ansible-playbook game_switch.yml --tags "game1"

Example Hosts file:
[win]
192.0.0.1

Be sure to run the PS1 script on each opearting system that will be controller by ansible. You will also need to use the same ansible password on each OS. Ensure that it is secure.
